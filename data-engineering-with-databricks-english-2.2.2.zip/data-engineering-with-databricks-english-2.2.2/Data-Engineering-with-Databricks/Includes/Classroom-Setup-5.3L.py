# Databricks notebook source
# MAGIC %run ./_utility-methods $lesson="5.3L"

# COMMAND ----------

DA.cleanup()
DA.init(create_db=False)
DA.conclude_setup()

